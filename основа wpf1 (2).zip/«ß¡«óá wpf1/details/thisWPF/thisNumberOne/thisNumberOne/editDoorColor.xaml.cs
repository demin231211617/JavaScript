﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using thisNumberOne.NewFolder1;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для editDoorColor.xaml
    /// </summary>
    public partial class editDoorColor : Page
    {
        public door_color _door_color = new door_color();
        public editDoorColor(door_color door_color)
        {
            InitializeComponent();
            _door_color = door_color;
            fioView.Text = _door_color.door_color_title;
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            _door_color.door_color_title = fioView.Text;
            DatabaseControl.UpdateDoorColor(_door_color);
            gaf.Content = new DoorColor();
        }
    }
}
