﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne.NewFolder1
{
    /// <summary>
    /// Логика взаимодействия для JobWork.xaml
    /// </summary>
    public partial class JobWork : Page
    {
        public JobWork()
        {
            InitializeComponent();
            JobWorking.ItemsSource = DatabaseControl.GetJobForView();
        }

        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            job p = JobWorking.SelectedItem as job;
            if (p != null)
            {
                ret.Content = new editAnAdditional(p);
            }
            else
                MessageBox.Show("Выберите элемент для изменения", "Ошибка при выборе объекта", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            job p = JobWorking.SelectedItem as job;
            if (p != null)
            {
                DatabaseControl.DelJob(JobWorking.SelectedItem as job);
                JobWorking.ItemsSource = null;
                JobWorking.ItemsSource = DatabaseControl.GetJobForView();
            }
            else
                MessageBox.Show("Выберите элемент для удаления", "Ошибка при удалении объекта", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            ret.Content = new addAnAdditional();
        }
    }
}
