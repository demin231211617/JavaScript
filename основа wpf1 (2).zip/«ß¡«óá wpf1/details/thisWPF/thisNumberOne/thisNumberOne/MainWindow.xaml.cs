﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //поле ввыода логина
        private void login_TextChanged(object sender, TextChangedEventArgs e)
        {
            //Обработчик на заполнение поля и появленияя кнопки очистить
            if(login.Text != "")
                clear.IsEnabled = true;
            else
                clear.IsEnabled = false;

            GetBrush();
        }

        //Поле для ввода для пароля
        private void passsword_PasswordChanged(object sender, RoutedEventArgs e)
        {
            //Обработчик на заполнение поля и появленияя кнопки очистить
            if (passsword.Password != "")
                clear.IsEnabled = true;
            else
                clear.IsEnabled = false;

            GetBrush();
        }


        public bool IsOpen = false;
        public bool IsOpen1 = false;
        //Метод для выявления ошибок
        public void GetBrush()
        {
            if (login.Text.Length < 8)
            {
                login.BorderBrush = Brushes.Red;
                IsOpen = false;
            }
            else
            {
                login.BorderBrush = Brushes.GreenYellow;
                IsOpen = true;
            }

            if (passsword.Password.Length < 8)
            {
                passsword.BorderBrush = Brushes.Red;
                IsOpen1 = false;
            }
            else
            {
                passsword.BorderBrush = Brushes.GreenYellow;
                IsOpen1 = true;
            }
        }

        private void enter_Click(object sender, RoutedEventArgs e)
        {
            GetBrush();
            string search = login.Text.Trim().ToLower();
            string search1 = passsword.Password.Trim().ToLower();
            List<employee_db> employee_Dbs = DatabaseControl.GetEmployeeList();
            List<employee_db> FilteredList = new List<employee_db>();
            foreach(employee_db p in employee_Dbs)
            {
                if((p.login.Contains(search) && login.Text != null) && (p.password_employee.Contains(search1) && passsword.Password != null)){
                    MessageBox.Show("Добро пожаловать ", p.employee_fio);
                    MainPage mainPage = new MainPage();
                    mainPage.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Неверный формат");
                }
            }
        }

        //Отчистка строк
        private void clear_Click(object sender, RoutedEventArgs e)
        {
            login.Text = string.Empty;
            passsword.Password = string.Empty;
        }

        //Выход из приложения
        private void cancellation_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        int counter = 0;
        private void registration_Click(object sender, RoutedEventArgs e)
        {
            counter++;
            if(counter > 3)
            {
                MessageBox.Show("Обнаруженна подозрительная активность. Ввод данныз запрещён!");
                registration.IsEnabled = false;
            }
            else
            {
                RepeatPassword repeatPassword = new RepeatPassword();
                repeatPassword.Show();
            }
        }
    }
}
