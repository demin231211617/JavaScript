﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Window
    {
        public MainPage()
        {
            InitializeComponent();

            //Главный экран часы
            DispatcherTimer LiveTime = new DispatcherTimer();
            LiveTime.Interval = TimeSpan.FromSeconds(1);
            LiveTime.Tick += timer_Tick;
            LiveTime.Start();
        }

        //Главный экран часы
        void timer_Tick(object sender, EventArgs e)
        {
            LiveTimeLabel.Content = DateTime.Now.ToString("HH:mm:ss");
        }

        //Кнопка Главная - при нажатии закрывает все страницы открытые ранее
        private void Home_Click(object sender, RoutedEventArgs e)
        {
            //Создание градиента при нажатии
            colorYellowHome.Offset = 1;
            colorYellowEmployee.Offset = 0;
            colorYellowPost.Offset = 0;
            colorYellowProduct.Offset = 0;
            colorYellowSales.Offset = 0;
            colorYellowUser.Offset = 0;

            ada.Content = null;
        }

        //Кнопка сотрудники - в данном окне будет хранится иформация для сотрудников предприятия
        private void strEmployee_Click(object sender, RoutedEventArgs e)
        {
            //Создание градиента при нажатии
            colorYellowHome.Offset = 0;
            colorYellowEmployee.Offset = 1;
            colorYellowPost.Offset = 0;
            colorYellowProduct.Offset = 0;
            colorYellowSales.Offset = 0;
            colorYellowUser.Offset = 0;

            ada.Content = new Employee();
        }

        //Кнопка клиенты - предназначенна для заполнения и занесения данных клиентов
        private void strUser_Click(object sender, RoutedEventArgs e)
        {
            //Создание градиента при нажатии
            colorYellowHome.Offset = 0;
            colorYellowEmployee.Offset = 0;
            colorYellowPost.Offset = 0;
            colorYellowProduct.Offset = 0;
            colorYellowSales.Offset = 0;
            colorYellowUser.Offset = 1;

            ada.Content = new User();
        }

        //Кнопка поставщики - предназначена для занесения информации о поставщиках
        private void Post_Click(object sender, RoutedEventArgs e)
        {
            //Создание градиента при нажатии
            colorYellowHome.Offset = 0;
            colorYellowEmployee.Offset = 0;
            colorYellowPost.Offset = 1;
            colorYellowProduct.Offset = 0;
            colorYellowSales.Offset = 0;
            colorYellowUser.Offset = 0;

            ada.Content = new Stoke();
        }

        //Кнопка товар
        private void strProduct_Click(object sender, RoutedEventArgs e)
        {
            colorYellowHome.Offset = 0;
            colorYellowEmployee.Offset = 0;
            colorYellowPost.Offset = 0;
            colorYellowProduct.Offset = 1;
            colorYellowSales.Offset = 0;
            colorYellowUser.Offset = 0;

            ada.Content = new product();
        }

        //Кнопка продажи
        private void strSales_Click(object sender, RoutedEventArgs e)
        {
            colorYellowHome.Offset = 0;
            colorYellowEmployee.Offset = 0;
            colorYellowPost.Offset = 0;
            colorYellowProduct.Offset = 0;
            colorYellowSales.Offset = 1;
            colorYellowUser.Offset = 0;

            ada.Content = new sales();
        }

        private void exit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void additionalInformation_Click(object sender, RoutedEventArgs e)
        {
            ada.Content = new CreateINformation();
            colorYellowHome.Offset = 0;
            colorYellowEmployee.Offset = 0;
            colorYellowPost.Offset = 0;
            colorYellowProduct.Offset = 0;
            colorYellowSales.Offset = 0;
            colorYellowUser.Offset = 0;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void daeer_TextChanged(object sender, TextChangedEventArgs e)
        {
            string search = daeer.Text.Trim().ToLower();
            List<employee_db> employee_Dbs = DatabaseControl.GetEmployeeList();
            List<employee_db> FilteredList = new List<employee_db>();
            foreach (employee_db p in employee_Dbs)
            {
                if ((p.login.Contains(search) && daeer.Text != null))
                {
                    FilteredList.Add(p);
                }
                else
                {
                    MessageBox.Show("Неверный формат");
                }


            }
        }
    }
}
