﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using thisNumberOne.NewDoor;

namespace thisNumberOne
{
    public class suppliers
    {
        [Key] public int suppliers_id { get; set; }
        public string suppliers_title { get; set; }
        public string suppliers_adress { get; set; }
        public string suppliers_phone { get; set; }
        public List<door> suppliersEnitities { get; set; }
        public List<pen> suppliersPenEntities { get; set; }
    }
}
