﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для addAnEmployee.xaml
    /// </summary>
    public partial class addAnEmployee : Page
    {
        public addAnEmployee()
        {
            InitializeComponent();
            fact.ItemsSource = DatabaseControl.GetJobView();
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            employee_db _tempEmployee = new employee_db();
            _tempEmployee.employee_fio = fioView.Text;
            _tempEmployee.employee_job_title = (int)fact.SelectedValue;
            _tempEmployee.employee_phone = phoneView.Text;
            _tempEmployee.employee_adress = adressView.Text;
            _tempEmployee.employee_wage = Convert.ToInt32(wageView.Text);
            _tempEmployee.login = loginView.Text;
            _tempEmployee.password_employee = passwordView.Text;
            _tempEmployee.serial_employee = sreialNumber.Text;
            DatabaseControl.AddEmployee(new employee_db
            {
                employee_fio = fioView.Text,
                employee_job_title = (int)fact.SelectedValue,
                employee_phone = phoneView.Text,
                employee_adress = adressView.Text,
                employee_wage = Convert.ToInt32(wageView.Text),
                login = loginView.Text,
                password_employee = passwordView.Text,
                serial_employee = sreialNumber.Text,
            });
            goout.Content = new Employee();
        }
    }
}
