﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для addAnSuppliers.xaml
    /// </summary>
    public partial class addAnSuppliers : Page
    {
        public addAnSuppliers()
        {
            InitializeComponent();
        }
        
        public Stoke suppliers = new Stoke();

        public void RefreshTable()
        {
            suppliers.supp.ItemsSource = null;
            suppliers.supp.ItemsSource = DatabaseControl.GetPhonesForView();
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            suppliers _tempSuppliers = new suppliers();
            try
            {
                if(customerVerification.CheckEmptySupp(firmView.Text, adressView.Text, phoneView.Text))
                {
                    _tempSuppliers.suppliers_title = firmView.Text;
                    _tempSuppliers.suppliers_phone = phoneView.Text;
                    _tempSuppliers.suppliers_adress = adressView.Text;
                    DatabaseControl.AddClientSuppliers(new suppliers
                    {
                        suppliers_title = firmView.Text,
                        suppliers_phone = phoneView.Text,
                        suppliers_adress = adressView.Text
                    });
                    suppliers.RefreshTable();
                    this.Content = null;
                }
            }
            catch
            {
                MessageBox.Show("Ошибка при вводе");
            }
        }
    }
}
