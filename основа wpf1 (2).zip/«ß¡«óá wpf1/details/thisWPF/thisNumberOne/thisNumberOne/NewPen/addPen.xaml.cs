﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using thisNumberOne.FolderPenColor;

namespace thisNumberOne.NewPen
{
    /// <summary>
    /// Логика взаимодействия для addPen.xaml
    /// </summary>
    public partial class addPen : Page
    {
        public addPen()
        {
            InitializeComponent();
            pc.ItemsSource = DatabaseControl.GetPenColorForView();
            ps.ItemsSource = DatabaseControl.GetSuppliersForView();
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            pen _tempPen = new pen();
            _tempPen.pen_title = nameView.Text;
            _tempPen.pen_cost = Convert.ToInt32(costView.Text);
            _tempPen.number_of_pen = Convert.ToInt32(numberView.Text);
            _tempPen.vendor_code_pen = Convert.ToInt32(venderView.Text);
            _tempPen.pen_supplies = (int)pc.SelectedValue;
            _tempPen.pen_color = (int)ps.SelectedValue;
            DatabaseControl.AddPen(new pen
            {
                pen_title = nameView.Text,
                pen_cost = Convert.ToInt32(costView.Text),
                number_of_pen = Convert.ToInt32(numberView.Text),
                vendor_code_pen = Convert.ToInt32(venderView.Text),
                pen_supplies = (int)pc.SelectedValue,
                pen_color = (int)ps.SelectedValue,
            });
            daf.Content = new PenProduct();
        }
    }
}
