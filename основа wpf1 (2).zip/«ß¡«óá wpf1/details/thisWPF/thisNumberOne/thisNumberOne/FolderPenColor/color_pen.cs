﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace thisNumberOne.FolderPenColor
{
    public class color_pen
    {
        [Key]public int pen_color_id { get; set; }
        public string pen_color_title { get; set; }
        public List<pen> penColorEntities { get; set; }
    }
}
