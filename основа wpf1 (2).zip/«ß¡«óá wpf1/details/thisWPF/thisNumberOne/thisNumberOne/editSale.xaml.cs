﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для editSale.xaml
    /// </summary>
    public partial class editSale : Page
    {
        public sale _tempSale = new sale();
        public editSale(sale sale)
        {
            InitializeComponent();
            dc.ItemsSource = DatabaseControl.GetPhonesForView();
            dg.ItemsSource = DatabaseControl.GetEmployeeList();
            ds.ItemsSource = DatabaseControl.GetDoorForView();
            db.ItemsSource = DatabaseControl.GetPenForView();
            fb.ItemsSource = DatabaseControl.GetPaymentForView();

            _tempSale = sale;
            nameView.Text = sale.sale_cost.ToString();
            dc.SelectedValue = sale.buyer;
            dg.SelectedValue = sale.saller;
            ds.SelectedValue = sale.sale_door;
            db.SelectedValue = sale.sale_pen;
            fb.SelectedValue = sale.sale_payment;
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            _tempSale.sale_cost = Convert.ToInt32(nameView.Text);
            _tempSale.buyer = (int)dc.SelectedValue;
            _tempSale.saller = (int)dg.SelectedValue;
            _tempSale.sale_door = (int)ds.SelectedValue;
            _tempSale.sale_pen = (int)db.SelectedValue;
            _tempSale.sale_payment = (int)fb.SelectedValue;
            DatabaseControl.UpdateSale(_tempSale);
            daf.Content = new sales();
        }
    }
}
