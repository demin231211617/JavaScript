﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace thisNumberOne
{
    public class customerVerification
    {
        //проверка для клиента
        static public bool CheckEmpty(string client_fio, string client_phone, string client_adress)
        {
            if((client_fio == "") || (client_phone == "") || (client_adress == ""))
            {
                MessageBox.Show("Строки не должны быть пустыми!", "Неверный ввод", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            return true;
        }

        //проверка для поставщиков
        static public bool CheckEmptySupp(string suppliers_title, string suppliers_adress, string suppliers_phone)
        {
            if((suppliers_title == "") || (suppliers_adress == "") || (suppliers_phone  == ""))
            {
                MessageBox.Show("Строки не должны быть пустыми!", "Неверный ввод", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            return true;
        }

        //Проверка для должностей
        static public bool CheckEmptyJob(string title_job, string job_description)
        {
            if ((title_job == "") ||(job_description == ""))
            {
                MessageBox.Show("Строки не должны быть пустыми!", "Неверный ввод", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            return true;
        }

        //Сотрудник
        static public bool CheckEmptyEmployee(string employee_fio, string employee_phone, string employee_adress, object employee_job_title, int employee_wage, string login, string password_employee, string serial_employee)
        {
            if((employee_fio == "")|| (employee_phone == "") || (employee_adress == "") || (employee_job_title == null) || (employee_wage == 0) || (login == "") || (password_employee == "") || (serial_employee == ""))
            {
                MessageBox.Show("Строки не должны быть пустыми!!!", "Пожалйста!!!", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            return true;
        }
    }
}
