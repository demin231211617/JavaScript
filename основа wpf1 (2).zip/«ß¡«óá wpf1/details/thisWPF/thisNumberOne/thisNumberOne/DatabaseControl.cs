﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using thisNumberOne.FolderGlassColor;
using thisNumberOne.FolderPenColor;
using thisNumberOne.NewDoor;

namespace thisNumberOne
{
    public class DatabaseControl
    {
        //Клиент
        public static List<client> GetPhonesForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.client.Include(p => p.clientEntities).ToList();
            }
        }

        public static void AddClient(client client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.client.Add(client);
                ctx.SaveChanges();
            }
        }

        public static void DelClient(client client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.client.Remove(client);
                ctx.SaveChanges();
            }
        }

        public static void UpdateClient(client client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                client _client = ctx.client.FirstOrDefault(p => p.client_id == client.client_id);

                if (_client == null)
                {
                    return;
                }

                _client.client_id = client.client_id;
                _client.client_fio = client.client_fio;
                _client.client_phone = client.client_phone;
                _client.client_adress = client.client_adress;

                ctx.SaveChanges();
            }
        }

        //Поставщики
        public static List<suppliers> GetSuppliersForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.suppliers.Include(p => p.suppliersEnitities).Include(p => p.suppliersPenEntities).ToList();
            }
        }

        public static void AddClientSuppliers(suppliers suppliers)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.suppliers.Add(suppliers);
                ctx.SaveChanges();
            }
        }

        public static void DelSuppliers(suppliers suppliers)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.suppliers.Remove(suppliers);
                ctx.SaveChanges();
            }
        }

        public static void UpdateClientsuppliers(suppliers suppliers)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                suppliers _suppliers = ctx.suppliers.FirstOrDefault(p => p.suppliers_id == suppliers.suppliers_id);

                _suppliers.suppliers_id = suppliers.suppliers_id;
                _suppliers.suppliers_phone = suppliers.suppliers_phone;
                _suppliers.suppliers_title = suppliers.suppliers_title;
                _suppliers.suppliers_adress = suppliers.suppliers_adress;

                ctx.SaveChanges();
            }
        }

        //Должность
        public static List<job> GetJobForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.job.ToList();
            }
        }

        public static void AddJob(job job)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.job.Add(job);
                ctx.SaveChanges();
            }
        }

        public static void DelJob(job job)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.job.Remove(job);
                ctx.SaveChanges();
            }
        }

        public static void UpdateJob(job job)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                job _job = ctx.job.FirstOrDefault(p => p.job_id == job.job_id);
        
                if (_job == null)
                {
                    return;
                }
        
                _job.title_job = job.title_job;
                _job.job_description = job.job_description;
        
                ctx.SaveChanges();
            }
        }

        //Cпособ оплаты

        public static List<payment> GetPaymentForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.payment.Include(p => p.paymentEntities).ToList();
            }
        }
        
        public static void AddPayment(payment payment)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.payment.Add(payment);
                ctx.SaveChanges();
            }
        }
        
        public static void DelPayment(payment payment)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.payment.Remove(payment);
                ctx.SaveChanges();
            }
        }
        
        public static void UpdatePayment(payment payment)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                payment _payment = ctx.payment.FirstOrDefault(p => p.payment_id == payment.payment_id);
        
                if (_payment == null)
                {
                    return;
                }
        
                _payment.payment_methods = payment.payment_methods;
        
                ctx.SaveChanges();
            }
        }

        //Цвет двери
        public static List<door_color> GetDoorColorForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.door_color.Include(p => p.door_colorEntities).ToList();
            }
        }

        public static void AddDoorColor(door_color door_color)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.door_color.Add(door_color);
                ctx.SaveChanges();
            }
        }

        public static void DelDoorColor(door_color door_color)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.door_color.Remove(door_color);
                ctx.SaveChanges();
            }
        }

        public static void UpdateDoorColor(door_color door_color)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                door_color _door_color = ctx.door_color.FirstOrDefault(p => p.door_color_id == door_color.door_color_id);

                if (_door_color == null)
                {
                    return;
                }

                _door_color.door_color_title = door_color.door_color_title;

                ctx.SaveChanges();
            }
        }

        //Цвет ручек

        public static List<color_pen> GetPenColorForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.color_pen.Include(p => p.penColorEntities).ToList();
            }
        }

        public static void AddPenColor(color_pen color_pen)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.color_pen.Add(color_pen);
                ctx.SaveChanges();
            }
        }

        public static void DelPenColor(color_pen color_pen)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.color_pen.Remove(color_pen);
                ctx.SaveChanges();
            }
        }

        public static void UpdatePenColor(color_pen color_pen)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                color_pen _pen_color = ctx.color_pen.FirstOrDefault(p => p.pen_color_id == color_pen.pen_color_id);

                if (_pen_color == null)
                {
                    return;
                }

                _pen_color.pen_color_title = color_pen.pen_color_title;

                ctx.SaveChanges();
            }
        }

        //Цвет стекла
        public static List<glass_color> GetGlassColorForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.glass_color.Include(p => p.glassColorEnitities).ToList();
            }
        }

        public static void AddGlassColor(glass_color glass_color)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.glass_color.Add(glass_color);
                ctx.SaveChanges();
            }
        }

        public static void DelGlassColor(glass_color glass_color)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.glass_color.Remove(glass_color);
                ctx.SaveChanges();
            }
        }

        public static void UpdateGlassColor(glass_color glass_color)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                glass_color _glass_color = ctx.glass_color.FirstOrDefault(p => p.glass_color_id == glass_color.glass_color_id);

                if (_glass_color == null)
                {
                    return;
                }

                _glass_color.glass_color_title = glass_color.glass_color_title;

                ctx.SaveChanges();
            }
        }

        //
        //Сотрудник
        //public static List<employee_db> GetEmployeeForView()
        //{
        //    using (DbAppContext ctx = new DbAppContext())
        //    {
        //        return ctx.employee_db.ToList();
        //    }
        //}
        //
        //public static void AddEmployee(employee_db employee_db)
        //{
        //    using (DbAppContext ctx = new DbAppContext())
        //    {
        //        ctx.employee_db.Add(employee_db);
        //        ctx.SaveChanges();
        //    }
        //}
        //
        //public static void DelEmployee(employee_db employee_db)
        //{
        //    using (DbAppContext ctx = new DbAppContext())
        //    {
        //        ctx.employee_db.Remove(employee_db);
        //        ctx.SaveChanges();
        //    }
        //}
        //
        //public static void UpdateEmployee(employee_db employee_db)
        //{
        //    using (DbAppContext ctx = new DbAppContext())
        //    {
        //        employee_db _employee_db = ctx.employee_db.FirstOrDefault(p => p.employee_id == employee_db.employee_id);
        //
        //        if (_employee_db == null)
        //        {
        //            return;
        //        }
        //
        //        _employee_db.employee_fio = employee_db.employee_fio;
        //        _employee_db.employee_phone = employee_db.employee_phone;
        //        _employee_db.employee_adress = employee_db.employee_adress;
        //        _employee_db.employee_job_title = employee_db.employee_job_title;
        //        _employee_db.employee_wage = employee_db.employee_wage;
        //        _employee_db.login = employee_db.login;
        //        _employee_db.password_employee = employee_db.password_employee;
        //        _employee_db.serial_employee = employee_db.serial_employee;
        //
        //        ctx.SaveChanges();
        //    }
        //}
        //public static List<employee_db> GetJobEmployeeForView()
        //{
        //    using (DbAppContext ctx = new DbAppContext())
        //    {
        //        return ctx.employee_db.Include(p => p.jobEntity).ToList();
        //    }
        //}
        //
        //public static List<job> GetJobEmployee1ForView()
        //{
        //    using (DbAppContext cxt = new DbAppContext())
        //    {
        //        return cxt.job.Include(p => p.employeeEntities).ToList();
        //    }
        //}
        //
        //public static void AddEmployee(employee_db employee)
        //{
        //    using (DbAppContext ctx = new DbAppContext())
        //    {
        //        ctx.employee_db.Add(employee);
        //        ctx.SaveChanges();
        //    }
        //}
        //
        //public static void DelEmployee(employee_db employee)
        //{
        //    using (DbAppContext ctx = new DbAppContext())
        //    {
        //        ctx.employee_db.Remove(employee);
        //        ctx.SaveChanges();
        //    }
        //}
        //
        //public static void Update(employee_db employee)
        //{
        //    using (DbAppContext ctx = new DbAppContext())
        //    {
        //        employee_db _employee = ctx.employee_db.FirstOrDefault(p => p.employee_id == employee.employee_id);
        //
        //        if(_employee == null)
        //        {
        //            return;
        //        }
        //
        //        _employee.employee_fio = employee.employee_fio;
        //        _employee.employee_phone = employee.employee_phone;
        //        _employee.employee_adress = employee.employee_adress;
        //        _employee.employee_job_title = employee.employee_job_title;
        //        _employee.employee_wage = employee.employee_wage;
        //        _employee.login = employee.login;
        //        _employee.password_employee = employee.password_employee;
        //        _employee.serial_employee = employee.serial_employee;
        //
        //        ctx.SaveChanges();
        //    }
        //}

        //Сотрудник
        public static List<employee_db> GetEmployeeList()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.employee_db.Include(p => p.jobEntity).Include(p => p.employeeEntities).ToList();
            }
        }

        public static List<job> GetJobView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.job.Include(p => p.employeeEntities).ToList();
            }
        }

        public static void AddEmployee(employee_db employee_db)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.employee_db.Add(employee_db);
                ctx.SaveChanges();
            }
        }

        public static void DelEmployee(employee_db employee_db)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.employee_db.Remove(employee_db);
                ctx.SaveChanges();
            }
        }

        public static void UpdateEmployee(employee_db employee_db)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                employee_db _employee_db = ctx.employee_db.FirstOrDefault(p => p.employee_id == employee_db.employee_id);

                if (_employee_db == null)
                {
                    return;
                }

                _employee_db.employee_fio = employee_db.employee_fio;
                _employee_db.employee_phone = employee_db.employee_phone;
                _employee_db.employee_adress = employee_db.employee_adress;
                _employee_db.employee_job_title = employee_db.employee_job_title;
                _employee_db.employee_wage = employee_db.employee_wage;
                _employee_db.login = employee_db.login;
                _employee_db.password_employee = employee_db.password_employee;
                _employee_db.serial_employee = employee_db.serial_employee;

                ctx.SaveChanges();
            }
        }

        //Двери
        public static List<door> GetDoorForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.door.Include(p => p.doorColorEnity).Include(p => p.glassColorEntity).Include(p => p.suppliersEntity).Include(p => p.doorEntities).ToList();
            }
        }

        public static void AddDoor(door door)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.door.Add(door);
                ctx.SaveChanges();
            }
        }
        public static void DelDoor(door door)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.door.Remove(door);
                ctx.SaveChanges();
            }
        }
        public static void UpdateDoor(door door)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                door _door = ctx.door.FirstOrDefault(p => p.door_id == door.door_id);

                if (_door == null)
                {
                    return;
                }

                _door.door_title = door.door_title;
                _door.door_model = door.door_model;
                _door.door_cost = door.door_cost;
                _door.number_ofdoors = door.number_ofdoors;
                _door.vendor_code_door = door.vendor_code_door;
                _door.door_color_pluse = door.door_color_pluse;
                _door.door_glass_pluse = door.door_glass_pluse;
                _door.door_suplliers = door.door_suplliers;

                //_employee_db.employee_fio = employee_db.employee_fio;
                //_employee_db.employee_phone = employee_db.employee_phone;
                //_employee_db.employee_adress = employee_db.employee_adress;
                //_employee_db.employee_job_title = employee_db.employee_job_title;
                //_employee_db.employee_wage = employee_db.employee_wage;
                //_employee_db.login = employee_db.login;
                //_employee_db.password_employee = employee_db.password_employee;
                //_employee_db.serial_employee = employee_db.serial_employee;

                ctx.SaveChanges();
            }
        }

        //Ручка
        public static List<pen> GetPenForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.pen.Include(p => p.penColorEnity).Include(p => p.suppliersPenEnity).Include(p => p.penEntities).ToList();
            }
        }

        public static void AddPen(pen pen)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.pen.Add(pen);
                ctx.SaveChanges();
            }
        }
        public static void DelPen(pen pen)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.pen.Remove(pen);
                ctx.SaveChanges();
            }
        }
        public static void UpdatePen(pen pen)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                pen _pen = ctx.pen.FirstOrDefault(p => p.pen_id == pen.pen_id);

                if (_pen == null)
                {
                    return;
                }

                _pen.pen_title = pen.pen_title;
                _pen.pen_cost = pen.pen_cost;
                _pen.number_of_pen = pen.number_of_pen;
                _pen.vendor_code_pen = pen.vendor_code_pen;
                _pen.pen_supplies = pen.pen_supplies;
                _pen.pen_color = pen.pen_color;

                //_employee_db.employee_fio = employee_db.employee_fio;
                //_employee_db.employee_phone = employee_db.employee_phone;
                //_employee_db.employee_adress = employee_db.employee_adress;
                //_employee_db.employee_job_title = employee_db.employee_job_title;
                //_employee_db.employee_wage = employee_db.employee_wage;
                //_employee_db.login = employee_db.login;
                //_employee_db.password_employee = employee_db.password_employee;
                //_employee_db.serial_employee = employee_db.serial_employee;

                ctx.SaveChanges();
            }
        }

        //Продажа
        public static List<sale> GetSaleForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.sale.Include(p => p.clientEntity).Include(p => p.doorEntity).Include(p => p.penEntity).Include(p => p.employeeEntity).Include(p => p.paymentEntity).ToList();
            }
        }

        public static void AddSale(sale sale)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.sale.Add(sale);
                ctx.SaveChanges();
            }
        }
        public static void DelSale(sale sale)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.sale.Remove(sale);
                ctx.SaveChanges();
            }
        }
        public static void UpdateSale(sale sale)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                sale _sale = ctx.sale.FirstOrDefault(p => p.sale_id == sale.sale_id);

                if (_sale == null)
                {
                    return;
                }

                _sale.sale_cost = sale.sale_cost;
                _sale.buyer = sale.buyer;
                _sale.sale_door = sale.sale_door;
                _sale.sale_pen = sale.sale_pen;
                _sale.saller = sale.saller;
                _sale.sale_payment = sale.sale_payment;

                //_employee_db.employee_fio = employee_db.employee_fio;
                //_employee_db.employee_phone = employee_db.employee_phone;
                //_employee_db.employee_adress = employee_db.employee_adress;
                //_employee_db.employee_job_title = employee_db.employee_job_title;
                //_employee_db.employee_wage = employee_db.employee_wage;
                //_employee_db.login = employee_db.login;
                //_employee_db.password_employee = employee_db.password_employee;
                //_employee_db.serial_employee = employee_db.serial_employee;

                ctx.SaveChanges();
            }
        }
    }
}
