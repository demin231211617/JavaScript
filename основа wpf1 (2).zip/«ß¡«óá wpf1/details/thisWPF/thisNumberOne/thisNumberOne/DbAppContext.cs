﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using thisNumberOne.FolderGlassColor;
using thisNumberOne.FolderPenColor;
using thisNumberOne.NewDoor;

namespace thisNumberOne
{
    public class DbAppContext : DbContext
    {
        public DbSet<client> client { get; set; }
        public DbSet<suppliers> suppliers { get; set; }
        public DbSet<job> job { get; set; }
        public DbSet<employee_db> employee_db { get; set; } 
        public DbSet<payment> payment { get; set; }
        public DbSet<door_color> door_color { get; set; }
        public DbSet<color_pen> color_pen { get; set; }
        public DbSet<glass_color> glass_color { get; set; }
        public DbSet<door> door { get; set; }
        public DbSet<pen> pen { get; set; }
        public DbSet<sale> sale { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql(
                "Host=localhost;Username=postgres;Password=root;Database=bellaPorta");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<employee_db>().HasOne(p => p.jobEntity).WithMany(p => p.employeeEntities);
            modelBuilder.Entity<door>().HasOne(p => p.doorColorEnity).WithMany(p => p.door_colorEntities);
            modelBuilder.Entity<door>().HasOne(p => p.glassColorEntity).WithMany(p => p.glassColorEnitities);
            modelBuilder.Entity<door>().HasOne(p => p.suppliersEntity).WithMany(p => p.suppliersEnitities);
            modelBuilder.Entity<pen>().HasOne(p => p.penColorEnity).WithMany(p => p.penColorEntities);
            modelBuilder.Entity<pen>().HasOne(p => p.suppliersPenEnity).WithMany(p => p.suppliersPenEntities);

            modelBuilder.Entity<sale>().HasOne(p => p.clientEntity).WithMany(p => p.clientEntities);
            modelBuilder.Entity<sale>().HasOne(p => p.doorEntity).WithMany(p => p.doorEntities);
            modelBuilder.Entity<sale>().HasOne(p => p.penEntity).WithMany(p => p.penEntities);
            modelBuilder.Entity<sale>().HasOne(p => p.employeeEntity).WithMany(p => p.employeeEntities);
            modelBuilder.Entity<sale>().HasOne(p => p.paymentEntity).WithMany(p => p.paymentEntities);

        }
    }
}
