﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для editAnEmployee.xaml
    /// </summary>
    public partial class editAnEmployee : Page
    {
        public employee_db _tempEmployee_db = new employee_db();
        public editAnEmployee(employee_db employee_db)
        {
            InitializeComponent();
            fact.ItemsSource = DatabaseControl.GetJobView();
            _tempEmployee_db = employee_db;
            fioView.Text = employee_db.employee_fio;
            fact.SelectedValue = employee_db.employee_job_title;
            phoneView.Text = employee_db.employee_phone;
            adressView.Text = employee_db.employee_adress;
            wageView.Text = employee_db.employee_wage.ToString();
            loginView.Text = employee_db.login;
            passwordView.Text = employee_db.password_employee;
            sreialNumber.Text = employee_db.serial_employee;
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            _tempEmployee_db.employee_fio = fioView.Text;
            _tempEmployee_db.employee_job_title = (int)fact.SelectedValue;
            _tempEmployee_db.employee_phone = phoneView.Text;
            _tempEmployee_db.employee_adress = adressView.Text;
            _tempEmployee_db.employee_wage = Convert.ToInt32(wageView.Text);
            _tempEmployee_db.login = loginView.Text;
            _tempEmployee_db.password_employee = passwordView.Text;
            _tempEmployee_db.serial_employee = sreialNumber.Text;
            DatabaseControl.UpdateEmployee(_tempEmployee_db);
            goout.Content = new Employee();
        }
    }
}
