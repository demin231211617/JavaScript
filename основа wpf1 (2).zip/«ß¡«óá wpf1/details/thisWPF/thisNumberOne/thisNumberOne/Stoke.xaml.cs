﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для Stoke.xaml
    /// </summary>
    public partial class Stoke : Page
    {
        public Stoke()
        {
            InitializeComponent();
            supp.ItemsSource = DatabaseControl.GetSuppliersForView();
        }

        public void RefreshTable()
        {
            supp.ItemsSource = null;
            supp.ItemsSource = DatabaseControl.GetPhonesForView();
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            fads.Content = new addAnSuppliers();
        }

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            suppliers p = supp.SelectedItem as suppliers;
            if(p != null)
            {
                fads.Content = new editAnSuppliers(p);
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения", "Ошибка при выборе объекта", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RemoveButton_Click(object sender, RoutedEventArgs e)
        {
            suppliers p = supp.SelectedItem as suppliers;

            if(p != null)
            {
                DatabaseControl.DelSuppliers(supp.SelectedItem as suppliers);
                supp.ItemsSource = null;
                supp.ItemsSource = DatabaseControl.GetSuppliersForView();
            }else
                MessageBox.Show("Выберите элемент для удаления", "Ошибка при удалении объекта", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
