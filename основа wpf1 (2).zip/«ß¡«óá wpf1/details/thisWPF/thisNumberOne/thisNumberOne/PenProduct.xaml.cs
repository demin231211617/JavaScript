﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using thisNumberOne.NewDoor;
using thisNumberOne.NewPen;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для PenProduct.xaml
    /// </summary>
    public partial class PenProduct : Page
    {
        public PenProduct()
        {
            InitializeComponent();
            pens.ItemsSource = DatabaseControl.GetPenForView();
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            ret.Content = new NewPen.addPen();
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            ret.Content = new product();
        }

        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            pen p = pens.SelectedItem as pen;
            if (p != null)
            {
                ret.Content = new editPen(p);
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            pen p = pens.SelectedItem as pen;
            if (p != null)
            {
                DatabaseControl.DelPen(pens.SelectedItem as pen);
                pens.ItemsSource = null;
                ret.Content = new PenProduct();
            }
            else
            {
                MessageBox.Show("Выберите элемент для удаления");
            }
        }
    }
}
