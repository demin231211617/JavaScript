﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using thisNumberOne.FolderPenColor;

namespace thisNumberOne.FolderGlassColor
{
    /// <summary>
    /// Логика взаимодействия для glassColor.xaml
    /// </summary>
    public partial class glassColor : Page
    {
        public glassColor()
        {
            InitializeComponent();
            glassColors.ItemsSource = DatabaseControl.GetGlassColorForView();
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            ret.Content = new FolderGlassColor.addGlassColor();
        }

        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            glass_color p = glassColors.SelectedItem as glass_color;
            if (p != null)
            {
                ret.Content = new editGlassColor(p);
            }
            else
                MessageBox.Show("Выберите элемент для изменения", "Ошибка при выборе объекта", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            glass_color p = glassColors.SelectedItem as glass_color;
            if (p != null)
            {
                DatabaseControl.DelGlassColor(glassColors.SelectedItem as glass_color);
                glassColors.ItemsSource = null;
                glassColors.ItemsSource = DatabaseControl.GetGlassColorForView();
            }
            else
                MessageBox.Show("Выберите элемент для удаления", "Ошибка при удалении объекта", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
