﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using thisNumberOne.NewDoor;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;


namespace thisNumberOne.FolderGlassColor
{
    public class glass_color
    {
        [Key]public int glass_color_id { get; set; }
        public string glass_color_title { get; set; }
        public List<door> glassColorEnitities { get; set; }
    }
}
