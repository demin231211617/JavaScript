﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne.NewDoor
{
    /// <summary>
    /// Логика взаимодействия для editDoor.xaml
    /// </summary>
    public partial class editDoor : Page
    {
        public door _tempDoor = new door();
        public editDoor(door door)
        {
            InitializeComponent();
            dc.ItemsSource = DatabaseControl.GetDoorColorForView();
            dg.ItemsSource = DatabaseControl.GetGlassColorForView();
            ds.ItemsSource = DatabaseControl.GetSuppliersForView();

            _tempDoor = door;
            nameView.Text = door.door_title;
            modelView.Text = door.door_model;
            numberView.Text = door.number_ofdoors.ToString();
            costView.Text = door.door_cost.ToString();
            venderView.Text = door.vendor_code_door.ToString();
            dc.SelectedValue = door.door_color_pluse;
            dg.SelectedValue = door.door_glass_pluse;
            ds.SelectedValue = door.door_suplliers;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            _tempDoor.door_title = nameView.Text;
            _tempDoor.door_model = modelView.Text;
            _tempDoor.number_ofdoors = Convert.ToInt32(numberView.Text);
            _tempDoor.door_cost = Convert.ToInt32(costView.Text);
            _tempDoor.vendor_code_door = venderView.Text;
            _tempDoor.door_color_pluse = (int)dc.SelectedValue;
            _tempDoor.door_glass_pluse = (int)dg.SelectedValue;
            _tempDoor.door_suplliers = (int)ds.SelectedValue;
            DatabaseControl.UpdateDoor(_tempDoor);
            daf.Content = new NewDoor.doorProduct();
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }
    }
}
