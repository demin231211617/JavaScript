export default [
  {
    id: '',
    name: 'All'
  },
  {
    id: 'salads',
    name: 'Salads'
  },
  {
    id: 'soups',
    name: 'Soups'
  },
  {
    id: 'chicken-dishes',
    name: 'Chicken dishes'
  },
  {
    id: 'beef-dishes',
    name: 'Beef dishes'
  },
  {
    id: 'seafood-dishes',
    name: 'Seafood dishes'
  },
  {
    id: 'vegetable-dishes',
    name: 'Vegetable dishes'
  },
  {
    id: 'bits-and-bites',
    name: 'Bits and bites'
  },
  {
    id: 'on-the-side',
    name: 'On the side'
  }
];
